# Fitness-Website

This is a mock-gym website school project teaching the fundamentals of HTML 5, CSS & JS. It includes a variety of features including internal/external links, images, custom fonts, embedded maps, consistent and detailed page styling, and support for mobile, tablet, and desktop devices.


[Home Page Sample]
![Screenshot (36)](https://user-images.githubusercontent.com/49052244/140564837-70506819-0c19-4949-83d1-1b0ec067e9ff.png)


[About Us Page Sample]
![Screenshot (37)](https://user-images.githubusercontent.com/49052244/140564851-25861b17-24fe-4600-b032-cda791f8aadf.png)


[Nutrition Page Sample]
![Screenshot (38)](https://user-images.githubusercontent.com/49052244/140564884-a63deb47-6d2f-437e-a042-30de5075325b.png)

[Our Classes Page Sample]
![Screenshot (39)](https://user-images.githubusercontent.com/49052244/140564915-d2b06529-6898-42fb-903e-fab51c64712a.png)
